import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class myapproveldoctor extends StatefulWidget {
  const myapproveldoctor({super.key});

  @override
  State<myapproveldoctor> createState() => _myapproveldoctorState();
}

class _myapproveldoctorState extends State<myapproveldoctor> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

    );
  }
}
