import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:rx_route/res/app_url.dart';

import '../../../../../app_colors.dart';
import '../../../../../constants/styles.dart';

class EmployeeDetailsPage extends StatefulWidget {
  final int employeeId;

  const EmployeeDetailsPage({required this.employeeId, Key? key}) : super(key: key);

  @override
  _EmployeeDetailsPageState createState() => _EmployeeDetailsPageState();
}

class _EmployeeDetailsPageState extends State<EmployeeDetailsPage> with TickerProviderStateMixin {
  Map<String, dynamic>? _employeeDetails;
  bool _isLoading = true;
  String? _errorMessage;
  late TabController _tabController;
  late TabController _taggedTabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _taggedTabController = TabController(length: 2, vsync: this);
    _fetchEmployeeDetails();
  }

  Future<void> _fetchEmployeeDetails() async {
    try {
      final response = await http.post(
        Uri.parse(AppUrl.single_employee_details),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'uniqueId': widget.employeeId}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success']) {
          setState(() {
            _employeeDetails = data['data'];
            _isLoading = false;
          });
        } else {
          setState(() {
            _errorMessage = data['message'];
            _isLoading = false;
          });
        }
      } else {
        setState(() {
          _errorMessage = 'Failed to load employee details';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'An error occurred: $e';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.whiteColor,
        leading: IconButton(
          icon: CircleAvatar(
            backgroundColor: Colors.white,
            child: Icon(
              Icons.arrow_back_ios_rounded,
              color: AppColors.primaryColor,
            ),
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Text(
          'Employee Details',
          style: text40016black,
        ),
        centerTitle: true,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _errorMessage != null
          ? Center(child: Text(_errorMessage!))
          : Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  color: AppColors.primaryColor,
                  width: double.infinity,
                  height: MediaQuery.of(context).size.height / 5.5,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 40,
                          child: Text(_employeeDetails?['name'][0] ?? ''),
                        ),
                        const SizedBox(width: 20),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${_employeeDetails!['name']}',
                              style: text60017,
                            ),
                            Text('${_employeeDetails!['designation']}', style: text40012),
                            Text('${_employeeDetails!['qualification']}', style: text40012),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Text('Basic Information', style: text50014black),
              const SizedBox(height: 10),
              TabBar(
                tabAlignment: TabAlignment.start,
                isScrollable: true,
                controller: _tabController,
                labelColor: AppColors.primaryColor,
                unselectedLabelColor: Colors.black54,
                indicatorColor: AppColors.primaryColor,
                tabs: const [
                  Tab(text: 'Details'),
                  Tab(text: 'Schedule'),
                  Tab(text: 'Tagged'),
                  Tab(text: 'History'),
                ],
              ),
              SizedBox(
                height: 400, // Adjust the height based on your content
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    _buildDetailsTab(),
                    _buildScheduleTab(),
                    _buildTaggedTab(),
                    _buildHistoryTab(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailsTab() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Mobile: ${_employeeDetails!['mobile']}', style: text50014black),
          Text('Gender: ${_employeeDetails!['gender']}', style: text50014black),
          Text('Date of Birth: ${_employeeDetails!['date_of_birth']}', style: text50014black),
          Text('Joining Date: ${_employeeDetails!['joining_date']}', style: text50014black),
        ],
      ),
    );
  }

  Widget _buildScheduleTab() {
    // Implement based on the employee's schedule
    return Container(); // Placeholder
  }

  Widget _buildTaggedTab() {
    return DefaultTabController(
      length: 2,
      child: Column(
        children: [
          TabBar(
            controller: _taggedTabController,
            labelColor: AppColors.primaryColor,
            unselectedLabelColor: Colors.black54,
            indicatorColor: AppColors.primaryColor,
            tabs: const [
              Tab(text: 'Projects'),
              Tab(text: 'Departments'),
            ],
          ),
          Expanded(
            child: TabBarView(
              controller: _taggedTabController,
              children: [
                _buildProjectsTab(),
                _buildDepartmentsTab(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProjectsTab() {
    // Implement based on employee's projects
    return Container(); // Placeholder
  }

  Widget _buildDepartmentsTab() {
    // Implement based on employee's departments
    return Container(); // Placeholder
  }

  Widget _buildHistoryTab() {
    // Implement based on employee's history
    return Container(); // Placeholder
  }
}
